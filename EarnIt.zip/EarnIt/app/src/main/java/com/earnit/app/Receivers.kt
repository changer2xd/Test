package com.earnit.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Alarms.ACTION_WATER -> {
                if (Store.enabled) Notifier.water(context)
                Alarms.scheduleWater(context, false)
            }
            Alarms.ACTION_SLEEP1 -> {
                if (Store.enabled) Notifier.sleep(context, 1)
                Alarms.scheduleSleep(context, 1)
            }
            Alarms.ACTION_SLEEP2 -> {
                if (Store.enabled) Notifier.sleep(context, 2)
                Alarms.scheduleSleep(context, 2)
            }
            Alarms.ACTION_STUDY_END -> Actions.onStudyEnd(context)
        }
    }
}

class ActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_WATER_DONE = "com.earnit.app.WATER_DONE"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_WATER_DONE) {
            Actions.drankWater(context)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Alarms.scheduleAll(context)
    }
}
