package com.earnit.app

import android.app.TimePickerDialog
import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen() {
    var showPicker by remember { mutableStateOf(false) }
    BackHandler(enabled = showPicker) { showPicker = false }

    if (showPicker) {
        AppPicker(onClose = { showPicker = false })
    } else {
        SettingsBody(onEditApps = { showPicker = true })
    }
}

@Composable
private fun SettingsBody(onEditApps: () -> Unit) {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(Store.enabled) }
    var strict by remember { mutableStateOf(Store.strict) }
    var manual by remember { mutableStateOf(Store.manualReps) }
    var confirmOff by remember { mutableStateOf(false) }
    var wStart by remember { mutableIntStateOf(Store.waterStartMin) }
    var wEnd by remember { mutableIntStateOf(Store.waterEndMin) }
    var wInt by remember { mutableIntStateOf(Store.waterIntervalMin) }
    var s1 by remember { mutableIntStateOf(Store.sleep1Min) }
    var s2 by remember { mutableIntStateOf(Store.sleep2Min) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            "Settings",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        SwitchRow(
            "Protection",
            "Locking and reminders. Turning it off resets your streak to 0.",
            enabled
        ) { want ->
            if (want) {
                Store.enabled = true
                enabled = true
                Alarms.scheduleAll(ctx)
            } else {
                confirmOff = true
            }
        }

        SectionTitle("Locked apps")
        OutlinedButton(onClick = onEditApps, modifier = Modifier.fillMaxWidth()) {
            Text("Choose apps (${Store.blockedApps.size} selected)")
        }
        SwitchRow(
            "Strict mode",
            "Lock every app except calls, messages, maps, settings and the keyboard, not just your chosen ones. Study time then opens everything except your chosen apps.",
            strict
        ) { on ->
            strict = on
            Store.strict = on
            GuardService.instance?.nudge()
        }
        SwitchRow(
            "Manual rep button",
            "Shows a +1 button in the workout screen as a backup if camera counting fails.",
            manual
        ) { on ->
            manual = on
            Store.manualReps = on
        }

        SectionTitle("Water reminders")
        TimeRow("First reminder", wStart) {
            wStart = it
            Store.waterStartMin = it
            Alarms.scheduleAll(ctx)
        }
        TimeRow("Last reminder", wEnd) {
            wEnd = it
            Store.waterEndMin = it
            Alarms.scheduleAll(ctx)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Every", modifier = Modifier.weight(1f))
            OutlinedButton(onClick = {
                wInt = maxOf(30, wInt - 15)
                Store.waterIntervalMin = wInt
                Alarms.scheduleAll(ctx)
            }) { Text("−") }
            Text("$wInt min")
            OutlinedButton(onClick = {
                wInt = minOf(360, wInt + 15)
                Store.waterIntervalMin = wInt
                Alarms.scheduleAll(ctx)
            }) { Text("+") }
        }

        SectionTitle("Sleep reminders (notification only, never locks)")
        TimeRow("First reminder", s1) {
            s1 = it
            Store.sleep1Min = it
            Alarms.scheduleAll(ctx)
        }
        TimeRow("Second reminder", s2) {
            s2 = it
            Store.sleep2Min = it
            Alarms.scheduleAll(ctx)
        }
    }

    if (confirmOff) {
        AlertDialog(
            onDismissRequest = { confirmOff = false },
            title = { Text("Turn protection off?") },
            text = { Text("Locking and reminders stop, and your streak resets to 0.") },
            confirmButton = {
                TextButton(onClick = {
                    Store.enabled = false
                    Store.resetStreak()
                    Alarms.cancelAll(ctx)
                    enabled = false
                    confirmOff = false
                    GuardService.instance?.nudge()
                }) { Text("Turn off") }
            },
            dismissButton = {
                TextButton(onClick = { confirmOff = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 14.dp)
    )
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        ) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun TimeRow(label: String, minutes: Int, onPick: (Int) -> Unit) {
    val ctx = LocalContext.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = {
            TimePickerDialog(
                ctx,
                { _, h, m -> onPick(h * 60 + m) },
                minutes / 60,
                minutes % 60,
                true
            ).show()
        }) { Text(Fmt.hm(minutes)) }
    }
}

@Composable
private fun AppPicker(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val apps = remember {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first != ctx.packageName }
            .sortedBy { it.second.lowercase() }
    }
    var selected by remember { mutableStateOf(Store.blockedApps) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onClose) { Text("← Back") }
            Text("Locked apps (${selected.size})", fontWeight = FontWeight.Bold)
        }
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(apps) { entry ->
                val pkg = entry.first
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selected = if (pkg in selected) selected - pkg else selected + pkg
                            Store.blockedApps = selected
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = pkg in selected, onCheckedChange = null)
                    Column(modifier = Modifier.padding(start = 12.dp)) {
                        Text(entry.second)
                        Text(
                            pkg,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
