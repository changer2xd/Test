package com.earnit.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** True when the locking (accessibility) service is switched on. */
fun isGuardEnabled(ctx: Context): Boolean {
    if (GuardService.instance != null) return true
    val flat = Settings.Secure.getString(
        ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val me = ComponentName(ctx, GuardService::class.java)
    return flat.split(':').any { ComponentName.unflattenFromString(it) == me }
}

/** Starts the first intent that this phone can actually open. */
fun Context.startFirst(vararg intents: Intent) {
    for (i in intents) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (e: Exception) {
            // try the next one
        }
    }
}
