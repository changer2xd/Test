package com.earnit.app

/** Every number you may want to tweak lives here. */
object Config {
    const val REPS_REQUIRED = 5
    const val WORKOUT_GRANT_MIN = 60L      // minutes earned per finished workout
    const val BANK_CAP_MIN = 120L          // you can never bank more than this
    const val BONUS_MIN = 5L               // the once-a-day "last dopamine hit"
    const val STUDY_MIN = 30L              // the once-a-day study window
    const val WARN_BEFORE_MIN = 5L         // warning before phone time runs out
    const val DAY_START_HOUR = 4           // "a day" rolls over at 04:00, so midnight is not a loophole
    const val COUNTDOWN_SECONDS = 10       // get-in-position countdown before reps are counted

    // Rep detection thresholds, in degrees (tune these if counting feels off)
    const val PUSHUP_DOWN = 105.0          // elbow angle at the bottom
    const val PUSHUP_UP = 150.0            // elbow angle at the top
    const val SITUP_UP = 95.0              // hip angle when sitting up
    const val SITUP_DOWN = 125.0           // hip angle when lying back
    const val MIN_LIKELIHOOD = 0.5f        // how sure the camera must be about the joints

    val DEFAULT_BLOCKED: Set<String> = setOf(
        // TikTok (package differs by region)
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go",
        // YouTube
        "com.google.android.youtube",
        // Supercell games
        "com.supercell.clashroyale", "com.supercell.brawlstars",
        // Discord
        "com.discord",
        // Telegram (official + web build + Telegram X)
        "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
        // X / Twitter
        "com.twitter.android", "com.twitter.android.lite"
    )
}
