package com.earnit.app

import android.content.Context

/** The rules: how time is earned, granted and spent. */
object Actions {

    private fun minutes(m: Long): Long = m * 60_000L

    fun completeWorkout(ctx: Context) {
        val cap = minutes(Config.BANK_CAP_MIN)
        Store.bankMs = minOf(Store.bankMs + minutes(Config.WORKOUT_GRANT_MIN), cap)
        Store.addWorkout()
        Store.recordWorkoutDay()
        Notifier.cancel(ctx, Notifier.ID_TIME_UP)
        Notifier.cancel(ctx, Notifier.ID_WORKOUT)
        GuardService.instance?.nudge()
    }

    /** The once-a-day 5 minutes. Only offered once your earned time is used up. */
    fun bonusAvailable(): Boolean =
        Store.enabled && Store.bonusDay != Store.dayKey() && Store.bankMs <= 0L && !studyActive()

    fun grantBonus(ctx: Context): Boolean {
        if (!bonusAvailable()) return false
        Store.markBonus()
        Store.bankMs = minutes(Config.BONUS_MIN)
        GuardService.instance?.nudge()
        return true
    }

    fun studyActive(): Boolean = Store.studyEndMs > System.currentTimeMillis()

    fun studyRemainingMs(): Long =
        (Store.studyEndMs - System.currentTimeMillis()).coerceAtLeast(0L)

    fun studyAvailable(): Boolean =
        Store.enabled && !studyActive() && Store.studyDay != Store.dayKey()

    fun startStudy(ctx: Context): Boolean {
        if (!studyAvailable()) return false
        Store.markStudy()
        val end = System.currentTimeMillis() + minutes(Config.STUDY_MIN)
        Store.studyEndMs = end
        Alarms.scheduleStudyEnd(ctx, end)
        GuardService.instance?.nudge()
        return true
    }

    fun onStudyEnd(ctx: Context) {
        if (Store.studyEndMs == 0L) return
        Store.studyEndMs = 0L
        Notifier.studyEnded(ctx)
        GuardService.instance?.nudge()
    }

    fun drankWater(ctx: Context) {
        Store.addWater()
        Notifier.cancel(ctx, Notifier.ID_WATER)
        Alarms.scheduleWater(ctx, true)
    }
}
