package com.earnit.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Schedules the water reminders, the sleep reminders and the end-of-study alarm. */
object Alarms {
    const val ACTION_WATER = "com.earnit.app.WATER"
    const val ACTION_SLEEP1 = "com.earnit.app.SLEEP1"
    const val ACTION_SLEEP2 = "com.earnit.app.SLEEP2"
    const val ACTION_STUDY_END = "com.earnit.app.STUDY_END"

    private fun pi(ctx: Context, action: String, req: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, req,
            Intent(ctx, AlarmReceiver::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun setAt(ctx: Context, atMs: Long, pi: PendingIntent) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, pi)
        }
    }

    fun cancelAll(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pi(ctx, ACTION_WATER, 100))
        am.cancel(pi(ctx, ACTION_SLEEP1, 101))
        am.cancel(pi(ctx, ACTION_SLEEP2, 102))
        Store.nextWaterAt = 0L
        Store.nextSleep1At = 0L
        Store.nextSleep2At = 0L
    }

    /** Re-plan everything from scratch (after boot, update, or a settings change). */
    fun scheduleAll(ctx: Context) {
        if (!Store.enabled) {
            cancelAll(ctx)
            return
        }
        scheduleWater(ctx, false)
        scheduleSleep(ctx, 1)
        scheduleSleep(ctx, 2)
    }

    /** Only plans what is missing, so it never disturbs an alarm that is already waiting. */
    fun ensureScheduled(ctx: Context) {
        if (!Store.enabled) return
        val now = System.currentTimeMillis()
        if (Store.nextWaterAt <= now) scheduleWater(ctx, false)
        if (Store.nextSleep1At <= now) scheduleSleep(ctx, 1)
        if (Store.nextSleep2At <= now) scheduleSleep(ctx, 2)
    }

    /** afterDone = true: you just drank, so the next reminder is one interval from now. */
    fun scheduleWater(ctx: Context, afterDone: Boolean) {
        if (!Store.enabled) return
        val now = System.currentTimeMillis()
        var at = nextWaterSlot(now + 5000L)
        if (afterDone) {
            val candidate = now + Store.waterIntervalMin * 60_000L
            if (inWaterWindow(candidate)) at = candidate
        }
        Store.nextWaterAt = at
        setAt(ctx, at, pi(ctx, ACTION_WATER, 100))
    }

    fun scheduleSleep(ctx: Context, which: Int) {
        if (!Store.enabled) return
        val minutes = if (which == 1) Store.sleep1Min else Store.sleep2Min
        val at = nextDaily(minutes, System.currentTimeMillis() + 5000L)
        if (which == 1) {
            Store.nextSleep1At = at
        } else {
            Store.nextSleep2At = at
        }
        setAt(ctx, at, pi(ctx, if (which == 1) ACTION_SLEEP1 else ACTION_SLEEP2, 100 + which))
    }

    fun scheduleStudyEnd(ctx: Context, atMs: Long) {
        setAt(ctx, atMs, pi(ctx, ACTION_STUDY_END, 110))
    }

    /** Next slot of: start, start+interval, ... up to and including the end time. */
    private fun nextWaterSlot(after: Long): Long {
        val start = Store.waterStartMin
        var end = Store.waterEndMin
        if (end <= start) end += 1440
        val step = maxOf(15, Store.waterIntervalMin)
        val zone = ZoneId.systemDefault()
        val base = LocalDate.now(zone).atStartOfDay(zone)
        for (dayOffset in -1L..1L) {
            var m = start
            while (m <= end) {
                val t = base.plusDays(dayOffset).plusMinutes(m.toLong()).toInstant().toEpochMilli()
                if (t > after) return t
                m += step
            }
        }
        return after + step * 60_000L
    }

    private fun inWaterWindow(ms: Long): Boolean {
        val z = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
        val m = z.hour * 60 + z.minute
        val start = Store.waterStartMin
        val end = Store.waterEndMin
        return if (end <= start) (m >= start || m <= end) else (m in start..end)
    }

    private fun nextDaily(minuteOfDay: Int, after: Long): Long {
        val zone = ZoneId.systemDefault()
        var t = LocalDate.now(zone).atStartOfDay(zone).plusMinutes(minuteOfDay.toLong())
        while (t.toInstant().toEpochMilli() <= after) {
            t = t.plusDays(1)
        }
        return t.toInstant().toEpochMilli()
    }
}
