package com.earnit.app

import android.content.Context
import android.content.SharedPreferences
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** All persistent state, backed by SharedPreferences. */
object Store {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        if (!::sp.isInitialized) {
            sp = ctx.applicationContext.getSharedPreferences("earnit", Context.MODE_PRIVATE)
        }
    }

    private fun putB(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    private fun putI(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    private fun putL(k: String, v: Long) { sp.edit().putLong(k, v).apply() }
    private fun putS(k: String, v: String) { sp.edit().putString(k, v).apply() }

    // ---------- settings ----------
    var enabled: Boolean
        get() = sp.getBoolean("enabled", true)
        set(v) { putB("enabled", v) }

    /** Strict mode: lock every non-essential app, not only the chosen ones. */
    var strict: Boolean
        get() = sp.getBoolean("strict", false)
        set(v) { putB("strict", v) }

    /** Show a manual "+1 rep" button in the workout screen (backup if the camera fails). */
    var manualReps: Boolean
        get() = sp.getBoolean("manualReps", false)
        set(v) { putB("manualReps", v) }

    var blockedApps: Set<String>
        get() = HashSet(sp.getStringSet("blocked", null) ?: Config.DEFAULT_BLOCKED)
        set(v) { sp.edit().putStringSet("blocked", HashSet(v)).apply() }

    var waterStartMin: Int
        get() = sp.getInt("waterStart", 12 * 60)
        set(v) { putI("waterStart", v) }

    var waterEndMin: Int
        get() = sp.getInt("waterEnd", 0)
        set(v) { putI("waterEnd", v) }

    var waterIntervalMin: Int
        get() = sp.getInt("waterInterval", 90)
        set(v) { putI("waterInterval", v) }

    var sleep1Min: Int
        get() = sp.getInt("sleep1", 23 * 60 + 30)
        set(v) { putI("sleep1", v) }

    var sleep2Min: Int
        get() = sp.getInt("sleep2", 0)
        set(v) { putI("sleep2", v) }

    // ---------- runtime state ----------
    var bankMs: Long
        get() = sp.getLong("bankMs", 0L)
        set(v) { putL("bankMs", v) }

    var studyEndMs: Long
        get() = sp.getLong("studyEnd", 0L)
        set(v) { putL("studyEnd", v) }

    var studyDay: String
        get() = sp.getString("studyDay", "") ?: ""
        set(v) { putS("studyDay", v) }

    var bonusDay: String
        get() = sp.getString("bonusDay", "") ?: ""
        set(v) { putS("bonusDay", v) }

    var nextWaterAt: Long
        get() = sp.getLong("nextWater", 0L)
        set(v) { putL("nextWater", v) }

    var nextSleep1At: Long
        get() = sp.getLong("nextSleep1", 0L)
        set(v) { putL("nextSleep1", v) }

    var nextSleep2At: Long
        get() = sp.getLong("nextSleep2", 0L)
        set(v) { putL("nextSleep2", v) }

    // ---------- streak ----------
    var streak: Int
        get() = sp.getInt("streak", 0)
        set(v) { putI("streak", v) }

    var bestStreak: Int
        get() = sp.getInt("bestStreak", 0)
        set(v) { putI("bestStreak", v) }

    var lastWorkoutDay: String
        get() = sp.getString("lastWorkoutDay", "") ?: ""
        set(v) { putS("lastWorkoutDay", v) }

    fun currentStreak(): Int {
        val last = lastWorkoutDay
        if (last.isEmpty()) return 0
        return try {
            val today = LocalDate.parse(dayKey())
            val d = LocalDate.parse(last)
            if (d == today || d == today.minusDays(1)) streak else 0
        } catch (e: Exception) {
            0
        }
    }

    fun recordWorkoutDay() {
        val today = dayKey()
        if (lastWorkoutDay == today) return
        val yesterday = LocalDate.parse(today).minusDays(1).toString()
        streak = if (lastWorkoutDay == yesterday) streak + 1 else 1
        lastWorkoutDay = today
        if (streak > bestStreak) bestStreak = streak
    }

    fun resetStreak() {
        streak = 0
        lastWorkoutDay = ""
    }

    // ---------- per-day history ----------
    /** The "day" a moment belongs to; it rolls over at Config.DAY_START_HOUR, not at midnight. */
    fun dayKey(nowMs: Long = System.currentTimeMillis()): String =
        Instant.ofEpochMilli(nowMs).atZone(ZoneId.systemDefault())
            .minusHours(Config.DAY_START_HOUR.toLong()).toLocalDate().toString()

    private fun dayInt(day: String, field: String): Int = sp.getInt("d:$day:$field", 0)

    private fun dayAdd(field: String, by: Int) {
        val k = "d:${dayKey()}:$field"
        putI(k, sp.getInt(k, 0) + by)
    }

    fun water(day: String = dayKey()): Int = dayInt(day, "water")
    fun addWater() = dayAdd("water", 1)

    fun workouts(day: String = dayKey()): Int = dayInt(day, "work")
    fun addWorkout() = dayAdd("work", 1)

    fun usedMs(day: String = dayKey()): Long = sp.getLong("d:$day:used", 0L)
    fun addUsed(ms: Long) {
        val k = "d:${dayKey()}:used"
        putL(k, sp.getLong(k, 0L) + ms)
    }

    fun studyDone(day: String): Boolean = dayInt(day, "study") > 0
    fun bonusDone(day: String): Boolean = dayInt(day, "bonus") > 0

    fun markStudy() {
        studyDay = dayKey()
        dayAdd("study", 1)
    }

    fun markBonus() {
        bonusDay = dayKey()
        dayAdd("bonus", 1)
    }
}
