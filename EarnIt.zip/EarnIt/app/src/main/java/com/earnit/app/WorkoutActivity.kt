package com.earnit.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseDetector
import com.google.mlkit.vision.pose.defaults.PoseDetectorOptions
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Live camera rep counter. Nothing is recorded or saved: frames are analysed and thrown away. */
class WorkoutActivity : ComponentActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var previewView: PreviewView
    private lateinit var tvCount: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvAngle: TextView
    private lateinit var pickRow: LinearLayout
    private lateinit var btnManual: Button
    private lateinit var btnClose: Button

    private val camExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val detector: PoseDetector = PoseDetection.getClient(
        PoseDetectorOptions.Builder()
            .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
            .build()
    )
    private val tone: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 80)
    } catch (e: Exception) {
        null
    }

    private var provider: ProcessCameraProvider? = null
    private var useFront = true
    private var exercise: Exercise? = null
    private var counter: RepCounter? = null
    private var reps = 0
    private var timer: CountDownTimer? = null

    @Volatile
    private var counting = false

    @Volatile
    private var finished = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                beginCountdown()
            } else {
                tvStatus.text = "Camera permission is needed to count your reps."
                pickRow.visibility = View.VISIBLE
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, size: Float): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.setShadowLayer(10f, 0f, 0f, Color.BLACK)
        return t
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        previewView = PreviewView(this)
        root.addView(previewView, FrameLayout.LayoutParams(MATCH, MATCH))

        val ui = LinearLayout(this)
        ui.orientation = LinearLayout.VERTICAL
        ui.setPadding(dp(16), dp(32), dp(16), dp(24))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(label("Workout", 20f), LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(button("🔄 Camera") { flipCamera() }, LinearLayout.LayoutParams(WRAP, WRAP))
        ui.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        ui.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        tvCount = label("0 / ${Config.REPS_REQUIRED}", 88f)
        tvCount.gravity = Gravity.CENTER
        ui.addView(tvCount, LinearLayout.LayoutParams(MATCH, WRAP))

        tvAngle = label("", 14f)
        tvAngle.gravity = Gravity.CENTER
        ui.addView(tvAngle, LinearLayout.LayoutParams(MATCH, WRAP))

        ui.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        tvStatus = label(
            "Pick an exercise. ${Config.REPS_REQUIRED} reps earns ${Config.WORKOUT_GRANT_MIN} minutes.",
            17f
        )
        tvStatus.gravity = Gravity.CENTER
        tvStatus.setBackgroundColor(Color.parseColor("#99000000"))
        tvStatus.setPadding(dp(12), dp(12), dp(12), dp(12))
        ui.addView(tvStatus, LinearLayout.LayoutParams(MATCH, WRAP))

        pickRow = LinearLayout(this)
        pickRow.orientation = LinearLayout.HORIZONTAL
        pickRow.addView(
            button("💪 Push-ups") { startExercise(Exercise.PUSHUP) },
            LinearLayout.LayoutParams(0, WRAP, 1f)
        )
        pickRow.addView(
            button("🔥 Sit-ups") { startExercise(Exercise.SITUP) },
            LinearLayout.LayoutParams(0, WRAP, 1f)
        )
        ui.addView(pickRow, LinearLayout.LayoutParams(MATCH, WRAP))

        btnManual = button("+1 rep (manual backup)") {
            if (counting && !finished) onRep()
        }
        btnManual.visibility = View.GONE
        ui.addView(btnManual, LinearLayout.LayoutParams(MATCH, WRAP))

        btnClose = button("Cancel") { finish() }
        ui.addView(btnClose, LinearLayout.LayoutParams(MATCH, WRAP))

        root.addView(ui, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
    }

    // ------------------------------------------------------------------ flow

    private fun startExercise(ex: Exercise) {
        exercise = ex
        counter = RepCounter(ex)
        reps = 0
        finished = false
        counting = false
        pickRow.visibility = View.GONE
        tvCount.text = "0 / ${Config.REPS_REQUIRED}"
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
            beginCountdown()
        } else {
            permLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun beginCountdown() {
        startCamera()
        val hint = "Prop the phone about 2 m away, side-on, with your whole body in frame."
        timer?.cancel()
        timer = object : CountDownTimer(Config.COUNTDOWN_SECONDS * 1000L, 1000L) {
            override fun onTick(msLeft: Long) {
                tvStatus.text = "$hint\n\nStarting in ${msLeft / 1000 + 1}"
            }

            override fun onFinish() {
                counting = true
                tvStatus.text = "Go! ${Config.REPS_REQUIRED} reps."
                if (Store.manualReps) btnManual.visibility = View.VISIBLE
                beep(300)
            }
        }.start()
    }

    private fun onRep() {
        if (finished) return
        reps++
        tvCount.text = "$reps / ${Config.REPS_REQUIRED}"
        beep(120)
        if (reps >= Config.REPS_REQUIRED) finishWorkout()
    }

    private fun finishWorkout() {
        finished = true
        counting = false
        Actions.completeWorkout(this)
        tvCount.text = "✅"
        tvAngle.text = ""
        tvStatus.text = "Done! +${Config.WORKOUT_GRANT_MIN} minutes unlocked."
        btnManual.visibility = View.GONE
        btnClose.text = "Close"
        beep(600)
        tvStatus.postDelayed({ if (!isFinishing) finish() }, 3500L)
    }

    private fun beep(ms: Int) {
        try {
            tone?.startTone(ToneGenerator.TONE_PROP_BEEP, ms)
        } catch (e: Exception) {
            // no sound, no problem
        }
    }

    // ------------------------------------------------------------------ camera + pose

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                provider = future.get()
                bindCamera()
            } catch (e: Exception) {
                tvStatus.text = "Camera error: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCamera() {
        val p = provider ?: return
        val preview = Preview.Builder().build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        val analysis = ImageAnalysis.Builder()
            .setTargetResolution(Size(480, 640))
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()
        analysis.setAnalyzer(camExecutor) { proxy -> analyze(proxy) }

        val selector =
            if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        try {
            p.unbindAll()
            p.bindToLifecycle(this, selector, preview, analysis)
        } catch (e: Exception) {
            tvStatus.text = "Camera error: ${e.message}"
        }
    }

    private fun flipCamera() {
        useFront = !useFront
        if (provider != null) bindCamera()
    }

    private fun analyze(proxy: ImageProxy) {
        val c = counter
        if (!counting || finished || c == null) {
            proxy.close()
            return
        }
        try {
            val bitmap = proxy.toBitmap()
            val input = InputImage.fromBitmap(bitmap, proxy.imageInfo.rotationDegrees)
            detector.process(input)
                .addOnSuccessListener(camExecutor) { pose -> handlePose(pose, c) }
                .addOnCompleteListener(camExecutor) { proxy.close() }
        } catch (e: Exception) {
            proxy.close()
        }
    }

    private fun handlePose(pose: Pose, c: RepCounter) {
        val result = c.update(pose)
        runOnUiThread {
            if (finished) return@runOnUiThread
            tvAngle.text = result.debug
            if (result.rep) onRep()
        }
    }

    override fun onDestroy() {
        timer?.cancel()
        try {
            detector.close()
        } catch (e: Exception) {
            // ignore
        }
        camExecutor.shutdown()
        try {
            tone?.release()
        } catch (e: Exception) {
            // ignore
        }
        super.onDestroy()
    }
}
