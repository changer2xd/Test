package com.earnit.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@Composable
fun HistoryScreen(tick: Long) {
    val today = LocalDate.parse(Store.dayKey())
    val days = (0 until 14).map { today.minusDays(it.toLong()).toString() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Text(
                "History",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("🔥 Streak: ${Store.currentStreak()} days", fontWeight = FontWeight.Bold)
                    Text(
                        "Best: ${Store.bestStreak} days",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "A day counts when you finish at least one workout. Days roll over at 04:00.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        items(days) { d -> DayRow(d) }
    }
}

@Composable
private fun DayRow(day: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(day, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
            val study = if (Store.studyDone(day)) "  📚" else ""
            val bonus = if (Store.bonusDone(day)) "  ⏱" else ""
            Text(
                "💧 ${Store.water(day)}   💪 ${Store.workouts(day)}   📱 ${Store.usedMs(day) / 60_000L} min$study$bonus",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
