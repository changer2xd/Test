package com.earnit.app

import android.Manifest
import android.app.AlarmManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

@Composable
fun SetupScreen(tick: Long) {
    val ctx = LocalContext.current
    val pkgUri = Uri.parse("package:${ctx.packageName}")

    val notifLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val camLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val notifOk = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
    val camOk = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) ==
        PackageManager.PERMISSION_GRANTED
    val alarmOk = Build.VERSION.SDK_INT < 31 ||
        ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    val battOk = ctx.getSystemService(PowerManager::class.java)
        .isIgnoringBatteryOptimizations(ctx.packageName)
    val guardOk = isGuardEnabled(ctx)

    val appInfo = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri)

    val openAppInfo: () -> Unit = { ctx.startFirst(appInfo) }
    val openAccessibility: () -> Unit = {
        ctx.startFirst(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
    val askNotif: () -> Unit = {
        if (Build.VERSION.SDK_INT >= 33) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    val askCam: () -> Unit = { camLauncher.launch(Manifest.permission.CAMERA) }
    val openExact: () -> Unit = {
        ctx.startFirst(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri), appInfo)
    }
    val openBattery: () -> Unit = {
        ctx.startFirst(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri),
            appInfo
        )
    }
    val openMiuiBattery: () -> Unit = {
        ctx.startFirst(
            Intent()
                .setComponent(
                    ComponentName(
                        "com.miui.powerkeeper",
                        "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"
                    )
                )
                .putExtra("package_name", ctx.packageName)
                .putExtra("package_label", "EarnIt"),
            appInfo
        )
    }
    val openMiuiAutostart: () -> Unit = {
        ctx.startFirst(
            Intent().setComponent(
                ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
            ),
            appInfo
        )
    }
    val openMiuiPerms: () -> Unit = {
        ctx.startFirst(
            Intent("miui.intent.action.APP_PERM_EDITOR")
                .setClassName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.permissions.PermissionsEditorActivity"
                )
                .putExtra("extra_pkgname", ctx.packageName),
            appInfo
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "Setup",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Do each step once. On Poco/MIUI the last four matter most: without them the phone can silently stop EarnIt.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Step(
            ok = guardOk,
            title = "1. Locking service",
            hint = "Turn on EarnIt under Accessibility. If the switch is greyed out (Android 13 blocks sideloaded apps): open App info, tap the three dots at the top right, choose Allow restricted settings, then try again.",
            actions = listOf("App info" to openAppInfo, "Accessibility" to openAccessibility)
        )
        Step(
            ok = notifOk,
            title = "2. Notifications",
            hint = "Needed for water, sleep and time warnings.",
            actions = listOf("Allow" to askNotif)
        )
        if (Build.VERSION.SDK_INT >= 31) {
            Step(
                ok = alarmOk,
                title = "3. Exact alarms",
                hint = "Lets reminders fire on the minute instead of a few minutes late.",
                actions = listOf("Open" to openExact)
            )
        }
        Step(
            ok = camOk,
            title = "4. Camera",
            hint = "Used live to count your reps. Nothing is recorded or saved.",
            actions = listOf("Allow" to askCam)
        )
        Step(
            ok = battOk,
            title = "5. Battery: no restrictions",
            hint = "Allow EarnIt to ignore battery optimisation.",
            actions = listOf("Allow" to openBattery)
        )
        Step(
            ok = null,
            title = "6. MIUI battery saver",
            hint = "Set EarnIt to No restrictions. If the page does not open, go to App info > Battery saver.",
            actions = listOf("Open" to openMiuiBattery)
        )
        Step(
            ok = null,
            title = "7. MIUI autostart",
            hint = "Switch Autostart on for EarnIt so reminders survive a restart.",
            actions = listOf("Open" to openMiuiAutostart)
        )
        Step(
            ok = null,
            title = "8. MIUI pop-ups",
            hint = "Allow Display pop-up windows while running in the background, so the Workout button on the lock screen can open this app.",
            actions = listOf("Open" to openMiuiPerms)
        )
        Step(
            ok = null,
            title = "9. Lock EarnIt in recents",
            hint = "Open the recent apps screen, long-press EarnIt and tap the lock icon so MIUI never closes it.",
            actions = emptyList()
        )
    }
}

@Composable
private fun Step(
    ok: Boolean?,
    title: String,
    hint: String,
    actions: List<Pair<String, () -> Unit>>
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val mark = when (ok) {
                true -> "✅"
                false -> "⚠️"
                null -> "ℹ️"
            }
            Text("$mark  $title", fontWeight = FontWeight.Bold)
            Text(
                hint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (actions.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (a in actions) {
                        OutlinedButton(onClick = a.second) { Text(a.first) }
                    }
                }
            }
        }
    }
}
