package com.earnit.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Alarms.ensureScheduled(this)
        setContent {
            EarnItTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
fun AppRoot() {
    var tab by remember { mutableIntStateOf(0) }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            tick = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val labels = listOf("Home", "History", "Settings", "Setup")
    val icons = listOf("🏠", "📅", "⚙️", "🔧")

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icons[i]) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (tab) {
                0 -> HomeScreen(tick) { tab = 3 }
                1 -> HistoryScreen(tick)
                2 -> SettingsScreen()
                else -> SetupScreen(tick)
            }
        }
    }
}

@Composable
fun InfoCard(text: String, buttonLabel: String? = null, onButton: () -> Unit = {}) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text)
            if (buttonLabel != null) {
                OutlinedButton(onClick = onButton) { Text(buttonLabel) }
            }
        }
    }
}

@Composable
fun HomeScreen(tick: Long, goSetup: () -> Unit) {
    val ctx = LocalContext.current
    val bank = Store.bankMs
    val cap = Config.BANK_CAP_MIN * 60_000L
    val studyOn = Actions.studyActive()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "EarnIt",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        if (!Store.enabled) {
            InfoCard("Protection is off. Locking and reminders are paused.")
        } else if (!isGuardEnabled(ctx)) {
            InfoCard(
                "Locking is not active yet. Turn on the locking service in Setup.",
                "Open Setup",
                goSetup
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Phone time left", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    Fmt.clock(bank),
                    style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                LinearProgressIndicator(
                    progress = { (bank.toFloat() / cap.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "🔥 ${Store.currentStreak()} day streak    💧 ${Store.water()} today    💪 ${Store.workouts()} today",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Button(
            onClick = { ctx.startActivity(Intent(ctx, WorkoutActivity::class.java)) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("💪 Workout: ${Config.REPS_REQUIRED} reps = +${Config.WORKOUT_GRANT_MIN} min")
        }

        if (Actions.bonusAvailable()) {
            OutlinedButton(
                onClick = { Actions.grantBonus(ctx) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("⏱ Last ${Config.BONUS_MIN} minutes (once a day)")
            }
        }

        if (studyOn) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("📚 Study time", fontWeight = FontWeight.Bold)
                    Text(
                        "${Fmt.clock(Actions.studyRemainingMs())} left. Your distracting apps stay locked.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else if (Actions.studyAvailable()) {
            OutlinedButton(
                onClick = { Actions.startStudy(ctx) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("📚 Start study time (${Config.STUDY_MIN} min, once a day)")
            }
        }

        OutlinedButton(
            onClick = { Actions.drankWater(ctx) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("💧 I drank water")
        }

        Text(
            "Phone time only counts down while your screen is unlocked and one of your locked apps is open.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
