package com.earnit.app

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.inputmethod.InputMethodManager

/** Decides what should happen when a given app is on screen. */
object Policy {
    enum class Decision { FREE, ALLOW, BLOCK }

    fun decide(ctx: Context, pkg: String): Decision {
        if (!Store.enabled) return Decision.FREE

        val isChosenApp = pkg in Store.blockedApps
        val controlled = if (Store.strict) !Exempt.isExempt(ctx, pkg) else isChosenApp
        if (!controlled) return Decision.FREE

        // Study time: the chosen distracting apps stay blocked, the hour is paused.
        // (In strict mode everything else is open during study.)
        if (Actions.studyActive()) {
            return if (isChosenApp) Decision.BLOCK else Decision.FREE
        }

        return if (Store.bankMs > 0L) Decision.ALLOW else Decision.BLOCK
    }
}

/** Apps that must always work in strict mode: calls, messages, maps, system, keyboard, launcher. */
object Exempt {
    private val fixed = setOf(
        "android", "com.android.systemui", "com.android.settings",
        "com.android.phone", "com.android.server.telecom", "com.android.incallui",
        "com.android.dialer", "com.google.android.dialer",
        "com.android.contacts", "com.google.android.contacts",
        "com.android.mms", "com.google.android.apps.messaging",
        "com.android.permissioncontroller", "com.google.android.permissioncontroller",
        "com.android.packageinstaller", "com.google.android.packageinstaller",
        "com.miui.securitycenter", "com.lbe.security.miui", "com.miui.powerkeeper",
        "com.miui.packageinstaller", "com.miui.home", "com.mi.android.globallauncher",
        "com.google.android.apps.maps",
        "com.android.deskclock", "com.google.android.deskclock"
    )

    private var dynamic: Set<String> = emptySet()
    private var dynamicAt = 0L

    fun isExempt(ctx: Context, pkg: String): Boolean {
        if (pkg == ctx.packageName || pkg in fixed) return true
        val now = SystemClock.elapsedRealtime()
        if (dynamicAt == 0L || now - dynamicAt > 60_000L) {
            dynamic = computeDynamic(ctx)
            dynamicAt = now
        }
        return pkg in dynamic
    }

    private fun computeDynamic(ctx: Context): Set<String> {
        val out = HashSet<String>()
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            for (r in ctx.packageManager.queryIntentActivities(home, 0)) {
                out.add(r.activityInfo.packageName)
            }
        } catch (e: Exception) {
        }
        try {
            val sms = Telephony.Sms.getDefaultSmsPackage(ctx)
            if (sms != null) out.add(sms)
        } catch (e: Exception) {
        }
        try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            val dialer = tm.defaultDialerPackage
            if (dialer != null) out.add(dialer)
        } catch (e: Exception) {
        }
        try {
            val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            for (m in imm.enabledInputMethodList) {
                out.add(m.packageName)
            }
        } catch (e: Exception) {
        }
        return out
    }
}
