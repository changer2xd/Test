package com.earnit.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Notifier {
    const val CH_WATER = "water"
    const val CH_SLEEP = "sleep"
    const val CH_TIMER = "timer"

    const val ID_WATER = 1
    const val ID_SLEEP1 = 2
    const val ID_SLEEP2 = 3
    const val ID_WARN = 4
    const val ID_TIME_UP = 5
    const val ID_STUDY_END = 6
    const val ID_WORKOUT = 7

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_WATER, "Water reminders", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SLEEP, "Sleep reminders", NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_TIMER, "Phone time and study", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun openActivity(ctx: Context, cls: Class<*>, req: Int): PendingIntent =
        PendingIntent.getActivity(
            ctx, req,
            Intent(ctx, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun post(ctx: Context, id: Int, b: NotificationCompat.Builder) {
        val nm = NotificationManagerCompat.from(ctx)
        if (nm.areNotificationsEnabled()) {
            nm.notify(id, b.build())
        }
    }

    private fun base(ctx: Context, channel: String, title: String, text: String): NotificationCompat.Builder =
        NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_drop)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

    fun water(ctx: Context) {
        val done = PendingIntent.getBroadcast(
            ctx, 11,
            Intent(ctx, ActionReceiver::class.java).setAction(ActionReceiver.ACTION_WATER_DONE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        post(
            ctx, ID_WATER,
            base(ctx, CH_WATER, "💧 Time to drink water", "Have a glass, then tap Done.")
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setContentIntent(openActivity(ctx, MainActivity::class.java, 10))
                .addAction(0, "Done 💧", done)
        )
    }

    fun sleep(ctx: Context, which: Int) {
        val text = if (which == 1) {
            "It is getting late. Start winding down."
        } else {
            "It is past midnight. Put the phone down and go to sleep."
        }
        post(
            ctx, if (which == 1) ID_SLEEP1 else ID_SLEEP2,
            base(ctx, CH_SLEEP, "😴 Go to sleep", text)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
        )
    }

    fun fiveLeft(ctx: Context) {
        post(
            ctx, ID_WARN,
            base(ctx, CH_TIMER, "⏳ ${Config.WARN_BEFORE_MIN} minutes of phone time left", "Wrap up what you are doing.")
        )
    }

    fun timeUp(ctx: Context) {
        post(
            ctx, ID_TIME_UP,
            base(
                ctx, CH_TIMER, "⏰ Phone time is up",
                "Do ${Config.REPS_REQUIRED} push-ups or sit-ups to earn ${Config.WORKOUT_GRANT_MIN} more minutes."
            ).setContentIntent(openActivity(ctx, WorkoutActivity::class.java, 12))
        )
    }

    fun workoutPrompt(ctx: Context) {
        post(
            ctx, ID_WORKOUT,
            base(ctx, CH_TIMER, "💪 Ready to work out?", "Tap to start your ${Config.REPS_REQUIRED} reps.")
                .setContentIntent(openActivity(ctx, WorkoutActivity::class.java, 13))
        )
    }

    fun studyEnded(ctx: Context) {
        post(
            ctx, ID_STUDY_END,
            base(ctx, CH_TIMER, "📚 Study time is over", "Your ${Config.STUDY_MIN} minutes are done. Nice work.")
        )
    }

    fun cancel(ctx: Context, id: Int) {
        NotificationManagerCompat.from(ctx).cancel(id)
    }
}
