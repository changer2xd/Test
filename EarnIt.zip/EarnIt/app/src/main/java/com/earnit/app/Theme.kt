package com.earnit.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val EarnItColors = darkColorScheme(
    primary = Color(0xFFF5B544),
    onPrimary = Color(0xFF1A1200),
    secondary = Color(0xFF7FB8E6),
    onSecondary = Color(0xFF00131F),
    secondaryContainer = Color(0xFF3B3322),
    onSecondaryContainer = Color(0xFFF5E3BD),
    background = Color(0xFF0F1720),
    onBackground = Color(0xFFE9EEF3),
    surface = Color(0xFF17212C),
    onSurface = Color(0xFFE9EEF3),
    surfaceVariant = Color(0xFF212D3A),
    onSurfaceVariant = Color(0xFFA9B6C3),
    surfaceContainer = Color(0xFF17212C),
    error = Color(0xFFFF8A80),
    errorContainer = Color(0xFF4A1F1F),
    onErrorContainer = Color(0xFFFFDAD6)
)

@Composable
fun EarnItTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = EarnItColors, content = content)
}
