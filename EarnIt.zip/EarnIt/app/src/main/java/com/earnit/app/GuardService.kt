package com.earnit.app

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * The lock. Once a second (and on every window change) it looks at which app is on screen,
 * asks Policy what to do, spends your phone time, and shows or hides the lock screen.
 */
class GuardService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GuardService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastEval = 0L
    private var wm: WindowManager? = null

    private var overlay: LinearLayout? = null
    private var tvTitle: TextView? = null
    private var tvInfo: TextView? = null
    private var btnWorkout: Button? = null
    private var btnBonus: Button? = null
    private var btnStudy: Button? = null

    private val ticker = object : Runnable {
        override fun run() {
            evaluate()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        lastEval = SystemClock.elapsedRealtime()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        handler.post { evaluate() }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        handler.removeCallbacks(ticker)
        hideOverlay()
        if (instance === this) instance = null
    }

    /** Ask for an immediate re-check (after time was earned, granted, or settings changed). */
    fun nudge() {
        handler.post { evaluate() }
    }

    // ------------------------------------------------------------------ core loop

    private fun evaluate() {
        val now = SystemClock.elapsedRealtime()
        val delta = (now - lastEval).coerceIn(0L, 2500L)
        lastEval = now

        if (Store.studyEndMs != 0L && Store.studyEndMs <= System.currentTimeMillis()) {
            Actions.onStudyEnd(this)
        }

        val pm = getSystemService(PowerManager::class.java)
        val km = getSystemService(KeyguardManager::class.java)
        // Only count and lock while the phone is really in use: screen on and unlocked.
        if (!Store.enabled || !pm.isInteractive || km.isKeyguardLocked) {
            hideOverlay()
            return
        }

        val pkg = foregroundPackage() ?: return
        when (Policy.decide(this, pkg)) {
            Policy.Decision.FREE -> hideOverlay()
            Policy.Decision.ALLOW -> {
                hideOverlay()
                consume(delta)
            }
            Policy.Decision.BLOCK -> showOverlay()
        }
    }

    private fun consume(deltaMs: Long) {
        if (deltaMs <= 0L) return
        val before = Store.bankMs
        val after = (before - deltaMs).coerceAtLeast(0L)
        Store.bankMs = after
        Store.addUsed(deltaMs)

        val warn = Config.WARN_BEFORE_MIN * 60_000L
        if (before > warn && after <= warn) Notifier.fiveLeft(this)
        if (before > 0L && after == 0L) Notifier.timeUp(this)
    }

    /** Top-most real app window (ignores keyboard, status bar, our own overlay). */
    private fun foregroundPackage(): String? {
        try {
            val ws: List<AccessibilityWindowInfo>? = windows
            if (ws != null) {
                for (w in ws) {
                    if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                        val p = w.root?.packageName?.toString()
                        if (p != null) return p
                    }
                }
            }
        } catch (e: Exception) {
            // fall through to the simpler lookup
        }
        return rootInActiveWindow?.packageName?.toString()
    }

    // ------------------------------------------------------------------ lock screen

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun pill(color: Int): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.RECTANGLE
        d.cornerRadius = dp(28).toFloat()
        d.setColor(color)
        return d
    }

    private fun makeButton(label: String, bg: String, fg: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.parseColor(fg))
        b.background = pill(Color.parseColor(bg))
        b.setPadding(dp(20), dp(14), dp(20), dp(14))
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(12)
        b.layoutParams = lp
        return b
    }

    private fun goHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    private fun openWorkout() {
        // The notification is the fallback in case this phone refuses background activity starts.
        Notifier.workoutPrompt(this)
        try {
            startActivity(
                Intent(this, WorkoutActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // tap the notification or open EarnIt from the home screen
        }
    }

    private fun buildOverlay() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Color.parseColor("#F20F1720"))
        root.setPadding(dp(28), dp(48), dp(28), dp(48))
        root.isClickable = true

        val title = TextView(this)
        title.textSize = 34f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER

        val info = TextView(this)
        info.textSize = 17f
        info.setTextColor(Color.parseColor("#B7C3CF"))
        info.gravity = Gravity.CENTER
        info.setPadding(0, dp(12), 0, dp(20))

        val workout = makeButton("💪 Earn time with a workout", "#F5B544", "#1A1200") {
            goHome()
            openWorkout()
            handler.postDelayed({ evaluate() }, 400L)
        }
        val bonus = makeButton("⏱ Last ${Config.BONUS_MIN} minutes (once a day)", "#27323F", "#FFFFFF") {
            Actions.grantBonus(this)
            evaluate()
        }
        val study = makeButton("📚 Study time (${Config.STUDY_MIN} min, once a day)", "#27323F", "#FFFFFF") {
            Actions.startStudy(this)
            goHome()
            handler.postDelayed({ evaluate() }, 400L)
        }
        val home = makeButton("Go home", "#27323F", "#FFFFFF") {
            goHome()
            handler.postDelayed({ evaluate() }, 400L)
        }

        root.addView(title)
        root.addView(info)
        root.addView(workout)
        root.addView(bonus)
        root.addView(study)
        root.addView(home)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm?.addView(root, lp)
            overlay = root
            tvTitle = title
            tvInfo = info
            btnWorkout = workout
            btnBonus = bonus
            btnStudy = study
        } catch (e: Exception) {
            overlay = null
        }
    }

    private fun showOverlay() {
        if (overlay == null) buildOverlay()
        if (overlay == null) return

        val studying = Actions.studyActive()
        tvTitle?.text = if (studying) "📚 Study time" else "🔒 Locked"
        tvInfo?.text = if (studying) {
            "Your distracting apps are locked for another ${Fmt.clock(Actions.studyRemainingMs())}.\nStay on it."
        } else {
            "No phone time left.\nDo ${Config.REPS_REQUIRED} push-ups or sit-ups to earn ${Config.WORKOUT_GRANT_MIN} minutes."
        }
        btnWorkout?.visibility = if (studying) View.GONE else View.VISIBLE
        btnBonus?.visibility = if (Actions.bonusAvailable()) View.VISIBLE else View.GONE
        btnStudy?.visibility = if (Actions.studyAvailable()) View.VISIBLE else View.GONE
    }

    private fun hideOverlay() {
        val o = overlay ?: return
        try {
            wm?.removeView(o)
        } catch (e: Exception) {
            // already gone
        }
        overlay = null
        tvTitle = null
        tvInfo = null
        btnWorkout = null
        btnBonus = null
        btnStudy = null
    }
}
