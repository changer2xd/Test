package com.earnit.app

import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseLandmark
import kotlin.math.acos
import kotlin.math.hypot

enum class Exercise { PUSHUP, SITUP }

class RepResult(val rep: Boolean, val debug: String)

/**
 * Counts reps from body-pose landmarks.
 *  - Push-up: elbow angle (shoulder-elbow-wrist). Bends below PUSHUP_DOWN, then straightens past PUSHUP_UP.
 *  - Sit-up:  hip angle (shoulder-hip-knee). Folds below SITUP_UP, then opens past SITUP_DOWN.
 * Angles do not depend on how the phone is rotated or mirrored.
 */
class RepCounter(private val exercise: Exercise) {

    private class Reading(val angle: Double, val conf: Float)

    private var smooth: Double? = null
    private var reached = false

    fun update(pose: Pose): RepResult {
        val raw = measure(pose)
            ?: return RepResult(false, "Can't see you clearly. Move back so your whole body is in frame.")
        val prev = smooth
        val s = if (prev == null) raw else prev * 0.6 + raw * 0.4
        smooth = s

        var rep = false
        if (exercise == Exercise.PUSHUP) {
            if (!reached && s < Config.PUSHUP_DOWN) {
                reached = true
            } else if (reached && s > Config.PUSHUP_UP) {
                reached = false
                rep = true
            }
        } else {
            if (!reached && s < Config.SITUP_UP) {
                reached = true
            } else if (reached && s > Config.SITUP_DOWN) {
                reached = false
                rep = true
            }
        }
        val phase = if (reached) "deep" else "start"
        return RepResult(rep, "angle ${s.toInt()}°  ($phase)")
    }

    private fun measure(pose: Pose): Double? {
        val l = joints(pose, true)
        val r = joints(pose, false)
        val best: Reading = when {
            l != null && r != null -> if (l.conf >= r.conf) l else r
            l != null -> l
            r != null -> r
            else -> return null
        }
        return if (best.conf >= Config.MIN_LIKELIHOOD) best.angle else null
    }

    private fun joints(pose: Pose, left: Boolean): Reading? {
        val a: PoseLandmark?
        val b: PoseLandmark?
        val c: PoseLandmark?
        if (exercise == Exercise.PUSHUP) {
            a = pose.getPoseLandmark(if (left) PoseLandmark.LEFT_SHOULDER else PoseLandmark.RIGHT_SHOULDER)
            b = pose.getPoseLandmark(if (left) PoseLandmark.LEFT_ELBOW else PoseLandmark.RIGHT_ELBOW)
            c = pose.getPoseLandmark(if (left) PoseLandmark.LEFT_WRIST else PoseLandmark.RIGHT_WRIST)
        } else {
            a = pose.getPoseLandmark(if (left) PoseLandmark.LEFT_SHOULDER else PoseLandmark.RIGHT_SHOULDER)
            b = pose.getPoseLandmark(if (left) PoseLandmark.LEFT_HIP else PoseLandmark.RIGHT_HIP)
            c = pose.getPoseLandmark(if (left) PoseLandmark.LEFT_KNEE else PoseLandmark.RIGHT_KNEE)
        }
        if (a == null || b == null || c == null) return null
        val conf = minOf(a.inFrameLikelihood, b.inFrameLikelihood, c.inFrameLikelihood)
        return Reading(angleAt(b, a, c), conf)
    }

    /** Angle in degrees at [vertex] between the lines to [p1] and [p2]. */
    private fun angleAt(vertex: PoseLandmark, p1: PoseLandmark, p2: PoseLandmark): Double {
        val v1x = p1.position.x - vertex.position.x
        val v1y = p1.position.y - vertex.position.y
        val v2x = p2.position.x - vertex.position.x
        val v2y = p2.position.y - vertex.position.y
        val n = hypot(v1x, v1y) * hypot(v2x, v2y)
        if (n < 1e-3f) return 180.0
        val cos = ((v1x * v2x + v1y * v2y) / n).coerceIn(-1f, 1f)
        return Math.toDegrees(acos(cos.toDouble()))
    }
}
