# EarnIt

Earn your phone time with push-ups or sit-ups. Built for a Poco M5s (Android 13, MIUI 14), sideloaded.

## What it does

| Feature | How it works |
|---|---|
| **Lock** | Your chosen apps (TikTok, YouTube, Clash Royale, Brawl Stars, Discord, Telegram, X by default) show a full-screen lock until you have phone time. Calls, messages, maps and EarnIt itself are never locked. |
| **Earn time** | 5 push-ups or 5 sit-ups, counted live by the front camera = **+1 hour**. Nothing is recorded or saved. You can bank at most 2 hours. |
| **The hour only runs while you use it** | It counts down only while the screen is on and unlocked and a locked app is open. |
| **5-minute warning** | A notification when 5 minutes of phone time are left, another when it is gone. |
| **Last 5 minutes** | Once a day, only when your time is empty. Button on the lock screen and the Home tab. |
| **Study time** | Once a day, 30 minutes, started by you (Home tab or the lock screen). Your locked apps stay locked for those 30 minutes, even if you have phone time banked, and the bank is paused, so study time never eats your hour. |
| **Water** | Notifications every 1.5 h from 12:00 to 0:00 (12:00, 13:30, 15:00, 16:30, 18:00, 19:30, 21:00, 22:30, 0:00). Tap **Done** and the next one comes 1.5 h after that. |
| **Sleep** | Notifications at 23:30 and 0:00. They never lock anything. |
| **Streak and history** | A day counts when you finish a workout. History shows 14 days of water, workouts, minutes used, study and bonus. |
| **Protection switch** | Settings > Protection off disables locking and reminders, and resets your streak. |

A "day" rolls over at **04:00**, not midnight, so the once-a-day extras cannot be reset by staying up past 0:00.

**Strict mode** (Settings, off by default): locks every app except calls, messages, maps, settings, clock and keyboard. During study time it opens everything except your chosen apps. Turn it on if that is what you meant by study time.

## Build the APK

### A) Android Studio (PC)
1. Install Android Studio. Open this folder (the one containing `settings.gradle.kts`).
2. Wait for the first Gradle sync (it downloads Gradle and libraries).
3. Build > Build APK(s). The file is `app/build/outputs/apk/debug/app-debug.apk`.

### B) No install: build in the cloud with GitHub (free)
1. Create a GitHub account and a new empty repository.
2. Upload everything from this folder, including the hidden `.github` folder. If `.github` will not upload, open the repo's Actions tab, choose "set up a workflow yourself", and paste the contents of `.github/workflows/build-apk.yml`.
3. Open the Actions tab. "Build APK" runs by itself (about 5 minutes). Open the finished run and download **EarnIt-debug-apk**. Unzip it to get `app-debug.apk`.

## Install on the Poco
1. Copy `app-debug.apk` to the phone and open it. Allow "install unknown apps" for your file manager. If Play Protect warns about an unknown app or accessibility, choose "Install anyway".
2. Open EarnIt > **Setup** tab and work down the list. The order matters on Android 13: first App info > three dots > **Allow restricted settings**, then Accessibility > EarnIt > On.
3. Do the MIUI steps (battery saver, autostart, pop-ups, lock in recents). Without them MIUI will eventually kill the lock.

## Doing reps
- Put the phone against something about 2 m away, **side-on to you**, so your whole body is in frame. The front camera shows the live count on screen.
- Pick Push-ups or Sit-ups. You get 10 seconds to get in position, then it counts. You hear a beep per rep.
- Small grey text shows the live joint angle. If reps are missed or counted early, change the angles in `Config.kt` (`PUSHUP_DOWN`, `PUSHUP_UP`, `SITUP_UP`, `SITUP_DOWN`) and rebuild.
- If the camera cannot count at all, switch on **Manual rep button** in Settings as a backup.

## Tuning
Every number (reps, minutes earned, bank cap, bonus, study length, warning time, day start) is at the top of `app/src/main/java/com/earnit/app/Config.kt`.

## Limits
- Android cannot make a lock truly unbreakable. Uninstalling, safe mode, or switching the accessibility service off bypasses it. This is an honor-system tool by design.
- Picture-in-picture video and background audio are not detected.
- This project was written without being able to compile it here. If the first build shows errors, send the error text and it can be fixed.
